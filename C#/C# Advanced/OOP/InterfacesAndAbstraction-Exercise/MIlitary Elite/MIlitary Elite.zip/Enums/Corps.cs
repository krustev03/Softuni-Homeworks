﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MIlitary_Elite
{
    public enum Corps
    {
        Airforces,

        Marines
    }
}
