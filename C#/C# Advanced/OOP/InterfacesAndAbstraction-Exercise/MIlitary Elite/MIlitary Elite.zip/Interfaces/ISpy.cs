﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MIlitary_Elite.Interfaces
{
    public interface ISpy : ISoldier
    {
        int Code { get; }
    }
}
