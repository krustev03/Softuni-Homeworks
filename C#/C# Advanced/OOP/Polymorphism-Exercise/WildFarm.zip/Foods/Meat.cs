﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity)
            : base(quantity)
        {
        }
    }
}
