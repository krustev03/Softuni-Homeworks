﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public interface IVehicleable
    {
        double FuelQuantity { get; }

        double FuelConsumptionPerKm { get; }

        void Drive(double km);

        void Refuel(double fuel);
    }
}
