﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Car : IVehicleable
    {
        public Car(double fuelQuantity, double fuelConsumptionPerKm)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumptionPerKm = fuelConsumptionPerKm + 0.9;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumptionPerKm { get; private set; }

        public void Drive(double km)
        {
            double neededFuel = km * this.FuelConsumptionPerKm;
            if (neededFuel > this.FuelQuantity)
            {
                Console.WriteLine("Car needs refueling");
            }
            else
            {
                this.FuelQuantity -= neededFuel;
                Console.WriteLine($"Car travelled {km} km");
            }
        }

        public void Refuel(double fuel)
        {
            this.FuelQuantity += fuel;
        }
    }
}
