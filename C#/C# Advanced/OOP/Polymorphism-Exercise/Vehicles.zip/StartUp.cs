﻿using System;

namespace Vehicles
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var carInfo = Console.ReadLine().Split();
            Car car = new Car(double.Parse(carInfo[1]), double.Parse(carInfo[2]));
            var truckInfo = Console.ReadLine().Split();
            Truck truck = new Truck(double.Parse(truckInfo[1]), double.Parse(truckInfo[2]));

            int numOfCommands = int.Parse(Console.ReadLine());

            for (int i = 0; i < numOfCommands; i++)
            {
                var commandArgs = Console.ReadLine().Split();
                string command = commandArgs[0];
                string vehicle = commandArgs[1];

                switch(command)
                {
                    case "Drive":

                        double distance = double.Parse(commandArgs[2]);

                        if (vehicle == "Car")
                        {
                            car.Drive(distance);
                        }
                        else if (vehicle == "Truck")
                        {
                            truck.Drive(distance);
                        }
                        break;
                    case "Refuel":

                        double liters = double.Parse(commandArgs[2]);

                        if (vehicle == "Car")
                        {
                            car.Refuel(liters);
                        }
                        else if (vehicle == "Truck")
                        {
                            truck.Refuel(liters);
                        }
                        break;
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:F2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:F2}");
        }
    }
}
