﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : IVehicleable
    {
        public Truck(double fuelQuantity, double fuelConsumptionPerKm)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumptionPerKm = fuelConsumptionPerKm + 1.6;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumptionPerKm { get; private set; }

        public void Drive(double km)
        {
            double neededFuel = km * this.FuelConsumptionPerKm;
            if (neededFuel > this.FuelQuantity)
            {
                Console.WriteLine("Truck needs refueling");
            }
            else
            {
                this.FuelQuantity -= neededFuel;
                Console.WriteLine($"Truck travelled {km} km");
            }
        }

        public void Refuel(double fuel)
        {
            this.FuelQuantity += fuel * 0.95;
        }
    }
}
