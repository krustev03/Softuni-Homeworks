﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IteratorsAndComparators
{
    class StartUp
    {
        public static void Main()
        {
            List<Person> persons = new List<Person>();

            int numOfEqualPeople = 0;
            int numOfNoEqualPeople = 0;

            while (true)
            {
                var command = Console.ReadLine();

                if (command == "END")
                {
                    break;
                }

                var parts = command.Split();

                Person personToAdd = new Person(parts[0], int.Parse(parts[1]), parts[2]);
                persons.Add(personToAdd);
            }

            int index = int.Parse(Console.ReadLine()) - 1;
            Person person = persons[index];

            for (int i = 0; i < persons.Count; i++)
            {
               
                var result = person.CompareTo(persons[i]);

                if (result == 0)
                {
                    numOfEqualPeople++;
                }
                else
                {
                    numOfNoEqualPeople++;
                }
                
            }

            if (numOfEqualPeople > 1)
            {
                Console.WriteLine($"{numOfEqualPeople} {numOfNoEqualPeople} {persons.Count}");
            }
            else
            {
                Console.WriteLine("No matches");
            }
        }
    }
}