﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace IteratorsAndComparators
{
    public class ListyIterator<T> : IEnumerable<T>
    {
        private const int CurrentInternalIndexInitialValue = 0;

        private int currIndex;
        private List<T> items;

        public ListyIterator()
        {
            this.items = new List<T>();
            this.currIndex = CurrentInternalIndexInitialValue;
        }

        public ListyIterator(IEnumerable<T> collectionData)
        {
            this.items = new List<T>(collectionData);
        }

        public bool Move()
        {
            if (this.items.Count - 1 > currIndex)
            {
                currIndex++;
                return true;
            }
            return false;
        }

        public T Print()
        {
            if (this.items.Count == 0)
            {
                throw new ArgumentNullException("Invalid Operation!");
            }
            return this.items[this.currIndex];
        }

        public bool HasNext() => this.items.Count - 1 > this.currIndex;

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < this.items.Count; i++)
            {
                yield return this.items[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        private class ListyIteratorEnumerator : IEnumerator<T>
        {

            private readonly List<T> items;

            private int currIndex;

            public ListyIteratorEnumerator(List<T> items)
            {
                this.Reset();
                this.items = items;
            }

            public T Current => this.items[this.currIndex];

            object IEnumerator.Current => this.Current;

            public void Dispose()
            { 
            }
       
            public bool MoveNext() => ++this.currIndex < this.items.Count;

            public void Reset() => this.currIndex = -1;
        }
    }
}
