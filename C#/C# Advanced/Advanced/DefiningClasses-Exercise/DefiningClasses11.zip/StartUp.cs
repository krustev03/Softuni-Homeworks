﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main()
        {
            var trainers = GetTrainers();
            PlayWithElements(trainers);
            PrintResult(trainers);
        }

        public static void PrintResult(Queue<Trainer> trainers)
        {
            foreach (var trainer in trainers.OrderByDescending(b => b.Badges))
            {
                Console.WriteLine($"{trainer.Name} {trainer.Badges} {trainer.Pokemons.Count}");
            }
        }

        public static Queue<Trainer> PlayWithElements(Queue<Trainer> trainers)
        {
            while (true)
            {
                var command = Console.ReadLine();

                if (command == "End")
                {
                    break;
                }

                foreach (var trainer in trainers)
                {
                    var pokemonWithElement = trainer.Pokemons.Where(p => p.Element == command).FirstOrDefault();

                    if (pokemonWithElement == null)
                    {
                        foreach (var pokemon in trainer.Pokemons)
                        {
                            pokemon.ReduceHealth();
                        }
                        trainer.ClearDeadPokemon();
                    }
                    else
                    {
                        trainer.AddBadge();
                    }
                }
            }

            return trainers;
        }

        public static Queue<Trainer> GetTrainers()
        {
            var trainers = new Queue<Trainer>();

            while (true)
            {
                var input = Console.ReadLine().Split();

                if (input[0] == "Tournament")
                {
                    break;
                }

                Pokemon pokemon = new Pokemon(input[1], input[2], int.Parse(input[3]));

                var currentTrainer = trainers.Where(t => t.Name == input[0]).FirstOrDefault();

                if (currentTrainer == null)
                {
                    currentTrainer = new Trainer(input[0]);
                    currentTrainer.Pokemons.Push(pokemon);
                    trainers.Enqueue(currentTrainer);
                }
                else
                {
                    currentTrainer.Pokemons.Push(pokemon);
                }
            }

            return trainers;
        }
    }
}
