﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DefiningClasses
{
    public class Trainer
    {
        private string name;
        private int badges;
        private Stack<Pokemon> pokemons;

        public string Name
        {
            get
            {
                return this.name;
            }
            private set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Name can not be empty.");
                }

                this.name = value;
            }
        }

        public Trainer(string name)
        {
            this.name = name;
            this.badges = 0;
            this.pokemons = new Stack<Pokemon>();
        }

        public int  Badges
        {
            get { return this.badges; }
        }

        public Stack<Pokemon> Pokemons
        {
            get { return this.pokemons; }
        }

        public void AddBadge()
        {
            this.badges++;
        }

        internal void ClearDeadPokemon()
        {
            if (this.pokemons.Count > 0 && this.pokemons.Where(p => p.Health <= 0).FirstOrDefault() != null)
            {
                this.pokemons = new Stack<Pokemon>(this.pokemons.Where(p => p.Health > 0));
            }
        }
    }
}
