﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Box<int>> boxes = new List<Box<int>>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine();
                Box<int> box = new Box<int>(int.Parse(input));

                boxes.Add(box);
            }

            var swaps = Console.ReadLine().Split().Select(int.Parse).ToArray();

            Swap(boxes, swaps[0], swaps[1]);

            foreach (var box in boxes)
            {
                Console.WriteLine(box);
            }
        }

        static void Swap<T>(IList<Box<T>> list, int index1, int index2)
        {
            Box<T> changer = list[index1];
            list[index1] = list[index2];
            list[index2] = changer;
        }
    }
}
