﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> boxes = new List<string>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine();
            
                boxes.Add(input);
            }

            var comparission = Console.ReadLine();

            Console.WriteLine(Compare(boxes, comparission)); 
        }

        public static int Compare<T>(IList<T> list, T element)
            where T : IComparable<T>
        {
            int counter = 0;

            foreach (var generic in list)
            {
                if (generic.CompareTo(element) > 0)
                {
                    counter++;
                }
            }
            return counter;
        }

        //static void Swap<T>(IList<Box<T>> list, int index1, int index2)
        //{
        //    Box<T> changer = list[index1];
        //    list[index1] = list[index2];
        //    list[index2] = changer;
        //}
    }
}
